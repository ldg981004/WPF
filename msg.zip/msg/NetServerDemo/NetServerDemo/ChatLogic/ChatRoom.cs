﻿using CommonLib.Network;
using SharedLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NetServerDemo.Model;

namespace NetServerDemo.ChatLogic
{
    internal class ChatRoom
    {
        private int _roomId = 0;

        
        private List<ChatUser> _users = new List<ChatUser>();
        //ServerRuntime _runtime = new ServerRuntime();
        

        public bool OnCreateChatRoom(List<string> message)
        {
            using var db = new EFContext();
            {
                ChatRoom_TBL ct = new ChatRoom_TBL();
                
                ct.ChatRoom_Id = message[1] + "-ChatRoom";
                ct.ChatRoom_User = message[1]; //User에는 방장이 들어가니깐 초기값을 방장으로 지정
                for (int i = 2; i < message.Count - 1; i++)
                {
                    ct.ChatRoom_User = ct.ChatRoom_User + " " + message[i];
                }
                ct.ChatRoom_Maker = message[1];
                ct.ChatRoom_Birth = DateTime.Now;

                db.Add(ct);
                db.SaveChanges();

                var cr = db.ChatRoom_TBLs!.LastOrDefault();
                // cr은 ChatRoom_TBLs의 마지막

                _roomId = cr!.ChatRoom_Num;
                // roomId는 마지막으로 만들어진 친구의 ChatRoom_num

                Console.WriteLine(message[1] + "의 채팅방 생성 완료");
                
                return true;
            }
        }

        public bool ChatRoomList(ConnectionID id, List<string> message)
        {
            using var db = new EFContext();
            {
                var p = db.ChatRoom_TBLs!.Where(d => d.ChatRoom_User!.Contains(message[1].ToString())).ToList();
                if (p.Count == 0)
                {
                    Console.WriteLine("DB-Isnull");
                    // 구현 부족
                }
                else
                {
                    List<string> chatroomListInfolist = new List<string>();
                    for (int i = 0; i < p.Count; i++)
                    {
                        chatroomListInfolist.Add(message[1].ToString());
                        chatroomListInfolist.Add(p[i].ChatRoom_Num.ToString());
                        chatroomListInfolist.Add(p[i].ChatRoom_Id.ToString());
                        chatroomListInfolist.Add(p[i].ChatRoom_User.ToString());
                        chatroomListInfolist.Add(p[i].ChatRoom_Maker);
                        ServerRuntime.SendMessage(id, PacketID.SC_ChatInfo, chatroomListInfolist);
                    }
                    
                }

                return true;
            }
        }

        //join

        //leave

        // broadcastAll
        public void BroadcastAll(List<string> msg)
        {
            foreach(var u in _users)
            {
                
            }
        }
    }
}
