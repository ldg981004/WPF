﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLib
{
    public enum PacketID    // 패킷아이디를 지정해 놓는 클래스
                            // Login을 1번으로 지정해서 그 다음부터는 1씩 증가
    {
        //client to server        
        CS_ReqSignUp = 1,
        CS_ReqLogin,
        CS_RecvMessage,

        // server to client
        SC_DupId, //4
        SC_SignUpResult, //5
        SC_NoId, //6
        SC_AlreadyLogin, //7
        SC_LogoutSuc,
        SC_LoginSuc,
        SC_PwInCor,
        SC_LoginResult,
        SC_LoginedUser,
        SC_AllUser,

        CS_LogOut,
        CS_ChatroomCreate,
        CS_ChatroomList,

        SC_ChatInfo,


        Max
    }

}
