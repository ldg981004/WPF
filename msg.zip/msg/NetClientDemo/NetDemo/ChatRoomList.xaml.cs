﻿using NetDemo.Network;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NetDemo
{
    /// <summary>
    /// ChatRoomList.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ChatRoomList : UserControl, INetworkEventListener
    {
        string member = "";
        string us = "";
        
        

        public ChatRoomList()
        {
            InitializeComponent();            
            NetworkProxy.Get.RegisterEventListener(this);
            //chat_panel.Children.Add(new ChatListButton()); 
        }
        public void AddLogMessage(string msg)
        {
            List<string> server_messages = Regex.Split(msg, "\r\n").ToList();

            for(int i =0; i < server_messages.Count - 1; i++)
            {
                if (server_messages[i].Contains("17"))
                {
                    var a = server_messages[i].Split(' ').ToList();
                    ChatListButton btn = new ChatListButton();
                    us = a[1].ToString();
                    for (int k = 4; k < a.Count - 1; k++)
                    {
                        member = member + a[k].ToString() + " ";
                    }
                    btn.chat_list_btn.Content = a[2].ToString() + "\r\n" + //채팅창 고유 번호
                                                a[3].ToString()  + "\r\n" + // 채팅창 이름
                                                member + "\r\n" + // 채팅창 멤버
                                                a.Last(); // 채팅창 방장
                    
                    chat_panel.Children.Add(btn);
                    member = "";

                }
            }
            lb_us.Content = us + "의 채팅방";

            if (server_messages[0].Contains("ChatRoom_info"))
            {
                NetworkProxy.Get.UnregisterEventListener(this);
                string user_info = msg.Replace("ChatRoom_info", us);
                //NetworkProxy.Get.SendMessage("ChatRoom_click" + " " + user_info); => 수정해야함
                chat_grid.Children.Clear();
                chat_grid.Children.Add(new ChatWindow());
            }

            
        }


        public void OnEventReceived(string msg)
        {
            AddLogMessage(msg);
        }
        
    }
}
