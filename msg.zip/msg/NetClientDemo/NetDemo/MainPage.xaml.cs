﻿using CommonLib.Network;
using NetDemo.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace NetDemo
{
    /// <summary>
    /// MainPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainPage : UserControl, INetworkEventListener
    {
        private string _user = null;
        private string _msg;
        public MainPage()
        {
            InitializeComponent();
            NetworkProxy.Get.RegisterEventListener(this);
            
        }

        public void AddLogMessage(string msg)
        {
            List<string> server_messages = msg.Split(' ').ToList();

            string login_user = "";
            
            switch (server_messages[0])
            {
                case "11":
                    byte[] bytedecode = Convert.FromBase64String(server_messages[1]);
                    string decodestring = Encoding.UTF8.GetString(bytedecode);  
                    lb_name.Content = "이름 : " + decodestring;
                    lb_id.Content = "아이디 : " + server_messages[2];
                    _user = server_messages[2];
                    lb_birth.Content = "생년월일 : " + server_messages[3];
                    break;

                case "12":
                    for (int i = 1; i < server_messages.Count - 1; i++)
                    {
                        login_user = login_user + server_messages[i].ToString();
                        Label lb = new Label();
                        lb.Content = server_messages[i].ToString() + " " + "온라인 상태";
                        login_user_panel.Children.Add(lb);
                    }
                    break;

                case "13":
                    // 전체 회원가입을 한 사용자를 보여줌
                    for (int i = 1; i < server_messages.Count() - 1; i++)
                    {
                        //Label tb = new Label();
                        CheckBox chat_box = new CheckBox();
                        chat_box.Width = 150;
                        chat_box.Content = server_messages[i].ToString();
                        if (chat_box.Content.ToString() == _user.ToString())
                        {
                            chat_box.IsEnabled = false;
                        }
                        // check box의 내용이 _user(자기 자신)와 같으면 체크 불가

                        user_panel.Children.Add(chat_box);
                    }
                    break;
            }
        }

        public void OnEventReceived(string msg)
        {
            AddLogMessage(msg);
        }

        private void log_out_Click(object sender, RoutedEventArgs e)
        {
            
            List<string> log_out_user = new List<string>()
            {
                "14",
                _user
            };
            NetworkProxy.Get.SendMessage(log_out_user);
            
            NetworkProxy.Get.UnregisterEventListener(this);
            main_grid.Children.Clear();
            main_grid.RowDefinitions.Clear();
            main_grid.ColumnDefinitions.Clear();
            main_grid.Children.Add(new Login());
            // 로그아웃 버튼 클릭 시 로그인 화면으로 다시 돌아감
        }

        private void invite_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            _msg = "";

            if (btn.Name == "invite" && _msg != "") // btn의 이름이 invite이고 _msg가 null이 아니면
            {
                IEnumerable<CheckBox> ChkBoxes = from checkbox in this.user_panel.Children.OfType<CheckBox>()
                                                 select checkbox;
                

                foreach(CheckBox chk in ChkBoxes)
                {
                    if(chk.IsChecked == true)
                    {
                        _msg = _msg + chk.Content.ToString() + " ";
                    }
                    
                }
                List<string> chatroomCreate = new List<string>()
                {
                    "15",
                    _user,
                    _msg
                };
                NetworkProxy.Get.SendMessage(chatroomCreate);
                MessageBox.Show("채팅방 생성 완료");
            }
            else if (_msg == "")
            {
                MessageBox.Show("사용자를 선택해 주세요", "선택 오류");
            }
        }

        private void Chat_Button_Click(object sender, RoutedEventArgs e)
        {
            List<string> chatroomList = new List<string>()
            {
                "16",
                _user
            };
            NetworkProxy.Get.SendMessage(chatroomList);
            User_Grid.Children.Clear();
            User_Grid.ColumnDefinitions.Clear();
            User_Grid.Children.Add(new ChatRoomList());
        }

        private void Home_Button_Click(object sender, RoutedEventArgs e)
        {
            //User_Grid.Children.Clear();
            MessageBox.Show("사용자 : " + _user, "현재 사용자");
        }

    }
}
