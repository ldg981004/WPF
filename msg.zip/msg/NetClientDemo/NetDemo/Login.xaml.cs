﻿using CommonLib.Network;
using NetDemo.Network;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NetDemo
{
    /// <summary>
    /// Login.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Login : UserControl, INetworkEventListener
    {
        public Login() 
        {
            InitializeComponent();
            NetworkProxy.Get.RegisterEventListener(this);
        }

        public void AddLogMessage(string msg)
        {
            List<string> server_messages = msg.Split(' ').ToList();

            switch (server_messages[0])
            {
                case "6":
                    {
                        MessageBox.Show("가입되지 않은 아이디", "ERROR");
                    }
                    break;

                case "7":
                    {
                        MessageBox.Show("이미 로그인 중인 아이디", "ERROR");
                    }
                    break;

                case "8":
                    {
                        MessageBox.Show("로그아웃 완료", "Success");
                    }
                    break;

                case "9":
                    {
                        MessageBox.Show("로그인 성공", "Success");
                        NetworkProxy.Get.UnregisterEventListener(this);
                        login_grid.Children.Clear();
                        login_grid.Children.Add(new MainPage());
                    }
                    break;

                case "10":
                    {
                        MessageBox.Show("비밀번호 오류", "ERROR");
                    }
                    break;

                default:
                    break;
            }
        }

        public void OnEventReceived(string msg)
        {
            AddLogMessage(msg);
        }

        private void Login_Button_Click(object sender, RoutedEventArgs e)
        {
            // 로그인 버튼 클릭 이벤트

            SHA256Managed sha256Managed = new SHA256Managed();

            byte[] encryptBytes1 = sha256Managed.ComputeHash(Encoding.UTF8.GetBytes(tb_pw.Password));
            String password = Convert.ToBase64String(encryptBytes1);
            
            List<string> login_list = new List<string>()
            {
                "2",
                tb_id.Text,
                password
            };

            NetworkProxy.Get.SendMessage(login_list);
        }        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // 회원가입 화면으로 이동
            NetworkProxy.Get.UnregisterEventListener(this);
            login_grid.Children.Clear();
            login_grid.Children.Add(new SignUp());
        }
    }
}
