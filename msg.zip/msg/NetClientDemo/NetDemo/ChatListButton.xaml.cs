﻿using NetDemo.Network;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NetDemo
{
    /// <summary>
    /// ChatListButton.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ChatListButton : UserControl, INetworkEventListener
    {
        public ChatListButton()
        {
            InitializeComponent();
            NetworkProxy.Get.RegisterEventListener(this);

        }

        private void chat_list_btn_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(chat_list_btn.Content.ToString());
            List<string> chat_info = Regex.Split(chat_list_btn.Content.ToString(), "\r\n").ToList();
            string a = chat_info[0].ToString() + " " + chat_info[1].ToString() + " " + chat_info[2].ToString() + " " + chat_info[3].ToString();  
            //NetworkProxy.Get.SendMessage("ChatRoom" + " " + a); => 수정해야함

        }

        public void OnEventReceived(string msg)
        {
            //throw new NotImplementedException();

            AddLogMessage(msg);
        }

        public void AddLogMessage(string msg)
        {

        }

    }
}
