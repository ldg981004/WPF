﻿using NetDemo.Network;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace NetDemo
{
    /// <summary>
    /// ChatWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ChatWindow : UserControl, INetworkEventListener
    {
        string room_num = "";
        string room_name = "";
        string member = "";
        string maker = "";
        public ChatWindow()
        {
            InitializeComponent();
            NetworkProxy.Get.RegisterEventListener(this);
            // 채팅방에 관련된 내용을 가져옴
            //NetworkProxy.Get.SendMessage("Previous_Record"); => 수정해야함
            
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            chat_window_grid.Children.Clear();
            chat_window_grid.RowDefinitions.Clear();
            //NetworkProxy.Get.SendMessage("채팅방리스트" + " " + who.Content); => 수정해야함
            chat_window_grid.Children.Add(new ChatRoomList());

        }

        public void OnEventReceived(string msg)
        {
            //throw new NotImplementedException();

            AddLogMessage(msg);
        }

        public void AddLogMessage(string msg)
        {
            List<string> server_messages = msg.Split(' ').ToList();
            
            if (server_messages[0].ToString() == "ChatRoom_click")
            {
                who.Content = server_messages[1].ToString();
                maker = server_messages.Last().ToString();
                room_num = server_messages[2].ToString();
                room_name = server_messages[3].ToString();
                
                for(int i = 4; i < server_messages.Count-2; i++)
                {
                    member = member + server_messages[i].ToString() + " ";
                }
                lb_mem.Content =  member;
                member = "";

            }
            else if (server_messages[0].ToString() == "Who_are_you")
            {
                //NetworkProxy.Get.SendMessage("I_am" + " " + room_num); => 수정해야함
            }
            //NetworkProxy.Get.UnregisterEventListener(this);
            
            else if (server_messages[0].Contains("Previous"))
            {
                List<string> pre_message = Regex.Split(msg.ToString(), "\r\n").ToList();

                for (int i = 0; i < pre_message.Count - 1; i++)
                {
                    List<string> pre_mes_split = pre_message[i].Split(' ').ToList();
                    Label textlb = new Label();
                    textlb.Content = pre_mes_split[1] + " : " + pre_mes_split[2] + " - " + pre_mes_split[3];
                    message_panel.Children.Add(textlb);
                }
                //NetworkProxy.Get.UnregisterEventListener(this);
            }

            else if (server_messages.Contains("Real_Time"))
            {
                if (room_num == server_messages[2])
                {
                    Label textlabel = new Label();
                    textlabel.Content = server_messages[1] + " : " + server_messages[4] + " - " + server_messages[3].ToString();
                    message_panel.Children.Add(textlabel);
                }

            }
        }

        private void submit_button_Click(object sender, RoutedEventArgs e)
        {
            if(String.IsNullOrWhiteSpace(tb_mes.Text))
            {
                MessageBox.Show("메시지를 입력하세요.", "ERROR");
                tb_mes.Text = null;
            }
            else
            {
                 /*Label textlabel = new Label();
                 textlabel.Content = who.Content + " : " + tb_mes.Text + " - " + DateTime.Now.ToString("yyyy-MM-dd");*/
                 //message_panel.Children.Add(textlabel);
                /*MessageBox.Show("보내는 사람 : " + who.Content.ToString() + "\r\n" +
                                "채팅방이름 : " + room_name + "\r\n" + 
                                "멤버 : " + lb_mem.Content + "\r\n" + 
                                "보내는시간 : " + DateTime.Now + "\r\n" + 
                                "내용 : " + tb_mes.Text.ToString());*/

                /*NetworkProxy.Get.SendMessage("Content" + " "
                               + who.Content.ToString() + " " 
                               + room_name + " " 
                               + lb_mem.Content.ToString().Replace(" ", string.Empty) + " " 
                               + tb_mes.Text.ToString().Replace(" ", string.Empty) + " " 
                               + room_num);*/
                // => 수정해야함 아래쪽 덩어리

                // 서버로 채팅에 관련된 내용을 보냄

                tb_mes.Text = null;
            }
        }
    }
}
